(function mounted() {
    getTableData();
})();

function guid() {
    //return parseInt(Date.now() + Math.random());
    function cero(n) {
        return (n < 10) ? '0' + n : n;
   }

   var today = new Date();
   var dd = today.getDate();
   var mm = today.getMonth() + 1;

   var yyyy = new Date().getFullYear().toString().substr(-2)
   if (dd < 10) { dd = '0' + dd }
   if (mm < 10) { mm = '0' + mm }
   today = yyyy + mm + dd ;

   var d = new Date();
   var HH = d.getHours(HH);
   var MM = d.getMinutes(MM);
   var ss = d.getSeconds(ss);
   
   if (HH > 12) {
       HH -= 12;
   } else if (HH === 0) {
       HH = 12;
   }

   var HHMM = cero(HH) + cero(MM);
   return resultado = `${today}${HHMM}${ss}`;
}


function fecha(){
    n =  new Date();
    //Año
    y = n.getFullYear();
    //Mes
    m = n.getMonth() + 1;
    //Día
    d = n.getDate();

    return fecha = d + "-" + m + "-" + y;
}
   

function saveMemberInfo() {
 
    var keys = ['nposte2', 'tipopos_dropdown','contador', 'calle', 'nocasa', 'zona', 'dir1', 'dir2', 'propiedad', 'obtext', 'cameraTakePicture', 'latpos', 'longpos']
    var obj = {};

    keys.forEach(function (item, index) {
        var result = document.getElementById(item).value;
        if (result) {
            obj[item] = result;
        }
    })

    var membersp = getmembersp();

    if (!membersp.length) {
        $('.show-table-info').addClass('hide');
    }

    if (Object.keys(obj).length) {
        var membersp = getmembersp();
        obj.id = guid();
        obj.fecha = fecha();
        membersp.push(obj);
        var data = JSON.stringify(membersp);
        localStorage.setItem("membersp", data);


        window.location.replace("dispositivo.html?idPostec="+guid());

        clearFields();
        insertIntoTableView(obj, getTotalRowOfTable());
        $('#addnewModal').modal('hide')
    }
}




function clearFields() {
    $('#input_form')[0].reset();
}

function getmembersp() {
    var memberRecord = localStorage.getItem("membersp");
    var membersp = [];
    if (!memberRecord) {
        return membersp;
    } else {
        membersp = JSON.parse(memberRecord);
        return membersp;
    }
}

function getFormattedmembersp() {
    var membersp = getmembersp();
    return membersp;
}

/**
 * Populating Table with stored data
 */
function getTableData() {
    $("#member_table").find("tr:not(:first)").remove();

    var searchKeyword = $('#member_search').val();
    var membersp = getFormattedmembersp();

    var filteredmembersp = membersp.filter(function (item, index) {
        return item.id.toLowerCase().includes(searchKeyword.toLowerCase()) ||
            item.contador.toLowerCase().includes(searchKeyword.toLowerCase()) ||
            item.fecha.toLowerCase().includes(searchKeyword.toLowerCase()) ||
            item.zona.toLowerCase().includes(searchKeyword.toLowerCase())
    });

    if (!filteredmembersp.length) {
        $('.show-table-info').removeClass('hide');
    } else {
        $('.show-table-info').addClass('hide');
    }

    filteredmembersp.forEach(function (item, index) {
        insertIntoTableView(item, index + 1);
    })
}

/**
 * Inserting data into the table of the view
 * 
 * @param {object} item 
 * @param {int} tableIndex 
 */
function insertIntoTableView(item, tableIndex) {
    var table = document.getElementById('member_table');
    var row = table.insertRow();
    var idCell = row.insertCell(0);
    var firstNameCell = row.insertCell(1);
    var lastNameCell = row.insertCell(2);
    var emailCell = row.insertCell(3);
    var fechazona = row.insertCell(4);


    var actionCell = row.insertCell(5);
    
    idCell.innerHTML = tableIndex;
    firstNameCell.innerHTML = item.id;
    lastNameCell.innerHTML = item.contador;
    emailCell.innerHTML = item.fecha;
    fechazona.innerHTML = item.calle +" "+item.nocasa+" "+item.zona+" "+item.dir1;

    
    var guid = item.id;

    //var getSinc = localStorage.getItem("userC", guid == guid);

    //alert(getSinc);
/*
    let localStorage = {
        "key1": {"name":"Kevin","country":"Canada","about":"Test","image":""},
        "key2": {"name":"Homer","country":"Canada","about":"Test","image":""}
    }
    for(let key of Object.keys(localStorage)){
        if(localStorage[key].hasOwnProperty('name')){
            console.log(localStorage[key]['name']);
        }
    }
  
  */

    actionCell.innerHTML = '<button class="btn btn-sm btn-default" onclick="showMemberData(' + guid + ')">Ver</button> ' +
        '<button class="btn btn-sm btn-primary" onclick="showEditModal(' + guid + ')">Editar</button> ' +
        '<button class="btn btn-sm btn-success"  id="'+guid+'" onclick="showSincModal(' + guid + ')">Sincronizar</button> '+
        '<button class="btn btn-sm btn-danger" onclick="showDeleteModal(' + guid + ')">Eliminar</button>';
}


/**
 * Get Total Row of Table
 */
function getTotalRowOfTable() {
    var table = document.getElementById('member_table');
    return table.rows.length;
}

/**
 * Show Single Member Data into the modal
 * 
 * @param {string} id 
 */
function showMemberData(id) {
    var allmembersp = getmembersp();
    var member = allmembersp.find(function (item) {
        return item.id == id;
    })

    $('#show_poste').val(member.nposte2);
    $('#tipopos_dropdown_show').val(member.tipopos_dropdown);
    $('#show_contador_ref').val(member.contador);
    $('#show_calle').val(member.calle);
    $('#show_nocasa').val(member.nocasa);
    $('#show_Zona').val(member.zona);
    $('#show_dir1').val(member.dir1);
    $('#show_dir2').val(member.dir2);
    $('#show_propiedad').val(member.propiedad);
    $('#show_obtext').val(member.obtext);
    $('#show_latpos').val(member.latpos);
    $('#show_longpos').val(member.longpos);
    $('#member_id').val(id);


    $('#showModal').modal();

}


/**
 * Show Edit Modal of a single member
 * 
 * @param {string} id 
 */
function showEditModal(id) {
    var allmembersp = getmembersp();
    var member = allmembersp.find(function (item) {
        return item.id == id;
    })

    $('#edit_poste').val(member.nposte2);
    $('#tipopos_dropdown_edit').val(member.tipopos_dropdown);
    $('#edit_contador_ref').val(member.contador);
    $('#edit_calle').val(member.calle);
    $('#edit_nocasa').val(member.nocasa);
    $('#edit_Zona').val(member.zona);
    $('#edit_dir1').val(member.dir1);
    $('#edit_dir2').val(member.dir2);
    $('#edit_propiedad').val(member.propiedad);
    $('#edit_obtext').val(member.obtext);
    $('#edit_latpos').val(member.latpos);
    $('#edit_longpos').val(member.longpos);
    $('#member_id').val(id);
    $('#editModal').modal();
}


/**
 * Store Updated Member Data into the storage
*/
function updateMemberData() {

    var allmembersp = getmembersp();
    var memberId = $('#member_id').val();

    var member = allmembersp.find(function (item) {
        return item.id == memberId;
    })

   // member.nposte2= $('#edit_poste').val();
    member.tipopos_dropdown=$('#tipopos_dropdown_edit').val();
    //member.contador=$('#edit_contador_ref').val();
    member.calle=$('#edit_calle').val();
    member.nocasa=$('#edit_nocasa').val();
    member.zona=$('#edit_Zona').val();
    member.dir1=$('#edit_dir1').val();
    member.dir2=$('#edit_dir2').val();
    member.propiedad=$('#edit_propiedad').val();
    member.obtext=$('#edit_obtext').val();
    member.latpos=$('#edit_latpos').val();
    member.longpos=$('#edit_longpos').val();

 

    var data = JSON.stringify(allmembersp);
    localStorage.setItem('membersp', data);

    $("#member_table").find("tr:not(:first)").remove();
    getTableData();
    $('#editModal').modal('hide')
}


function showDeleteModal(id) {
    $('#deleted-member-id').val(id);
    $('#deleteDialog').modal();
}

function showSincModal(id) {
    $('#sinc-member-id').val(id);
    $('#sincDialog').modal();
}


function sinCro(){
    //alert("esto es una prueba");
    var id = $('#sinc-member-id').val();
    var allmembersp = getmembersp();

    var getInv = localStorage.getItem("inventario");
    

    var member = allmembersp.find(function (item) {
        return item.id == id;
    })

    $.ajax({
        type: 'post',
        url: 'http://190.149.224.94:9800/ords/gauss/read/insposte',
        dataType: 'json',
        data: JSON.stringify({
                "poscorr": 	member.id,
                "inv": getInv,
                "posnum": member.nposte2,
                "posref": member.posref,
                "calle": member.calle,
                "casanum": member.nocasa,
                "zona": member.zona,
                "dir1": member.dir1,
                "dir2": member.dir2,
                "propiedad": member.propiedad,
                "x": member.latpos,
                "y": member.longpos,
                "fechor": member.fecha,
                "obs": member.obtext,
                "depto": "GT",
                "muni": "MIX",
                "usr": "HJ",
                "tpos": "C",
                "sinc": "S",
                "cont": "",
                "fotoclob": member.cameraTakePicture
         }),
        contentType: 'application/json; charset=utf-8',
        success: function (l) {
            //alert("Done");
            //console.log("Enviado con exito!");
        },

        statusCode: {
            200: function() {
                alert('Poste sincronizado con Exito');
                //console.log("enviado con exito!!!!");

                //document.getElementById("dis_sinc").disabled = false;

                $('#'+member.id).attr("disabled", true);

                //$('#'+member.id).hide();

                //$('#'+member.id).addClass("hidebu");


                var saveIdsinc = member.id;


var user = JSON.stringify({saveIdsinc}),
   users = localStorage.getItem('userC');

users = users ? JSON.parse(users) : [];

users.push(user);

localStorage.setItem("userC", JSON.stringify(users)); 


                ///var disabledSinc = localStorage.setItem('disablesinc', disablesinc);
                //var idSinc = localStorage.setItem('idsincButton', member.id);

                //$('#dis_sinc').val(member.id);
                ///alert("pasa por disable sinc "+disabledSinc);
                //alert("pasa por id sinc"+idSinc);
                //console.log(disabledSinc);
                //console.log(idSinc);

                //$("#member_table").find("tr:not(:first)").remove();

                //$(member.id).remove();

                //localStorage.setItem('saveIdsinc', saveIdsinc);

                //console.log(saveIdsinc);


/*
                    var itemsC = [];
                    itemsC.push(member.id);
                    localStorage.setItem("itemC", JSON.stringify(saveIdsinc));
*/              
//var storedNames = JSON.parse(localStorage.getItem("names"));  



//var namesArr = [];  
//namesArr.push(saveIdsinc); //Add the text 'item1' to nameArr
//localStorage.setItem('namesC', JSON.stringify(namesArr));  

/*
var object = {
    idSinc: saveIdsinc
}

localStorage.setItem("object", JSON.stringify(object));
//object = JSON.parse(localStorage.getItem("object"));


var array = [object];

localStorage.setItem("array", JSON.stringify(array));
array = JSON.parse(localStorage.getItem("array"));
*/

/*
var user = {
    idSinc: saveIdsinc
}

var record = JSON.stringify(user);
localStorage.setItem("idSinc", record); 


//console.log(typeof array); //object
//console.log(array); //[1, 2, 3]
*/



//console.log(typeof object); //object
//console.log(object); //Object {x: 12, y: 56}



              },

            404: function() {
                alert('EL poste no se sincronizo con exito. Problemas con el Servidor.');
              //alert('page not found');
              //console.log("page not found");
            },
        
            400: function() {
                alert('EL poste no se sincronizo con exito. Intente luego.');
               //alert('bad request');
               ///console.log("bad Request");
           },

           500: function() {
            alert('EL poste ya fue sincronizado.');
            //alert('bad request');
            //console.log("error");

            }

        }


    });

    $('#sincDialog').modal('hide');
    getTableData();

}

function deleteMemberData() {
    var id = $('#deleted-member-id').val();
    var storageUsers = JSON.parse(localStorage.getItem('membersp'));

    var newData = [];

    newData = storageUsers.filter(function (item, index) {
        return item.id != id;
    });

    var data = JSON.stringify(newData);

    localStorage.setItem('membersp', data);
    $("#member_table").find("tr:not(:first)").remove();
    $('#deleteDialog').modal('hide');
    getTableData();

}

/**
 * Sorting table data through type
 */
function sortBy(type)
{
    $("#member_table").find("tr:not(:first)").remove();

    var totalClickOfType = parseInt(localStorage.getItem(type));
    if(!totalClickOfType) {
        totalClickOfType = 1;
        localStorage.setItem(type, totalClickOfType);
    } else {
        if(totalClickOfType == 1) {
            totalClickOfType = 2;
        } else {
            totalClickOfType = 1;
        }
        localStorage.setItem(type, totalClickOfType);
    }

    var searchKeyword = $('#member_search').val();
    var membersp = getFormattedmembersp();

    var sortedmembersp = membersp.sort(function (a, b) {
        return (totalClickOfType == 2) ? a[type] > b[type] : a[type] < b[type];
    });

    sortedmembersp.forEach(function (item, index) {
        insertIntoTableView(item, index + 1);
    })
}