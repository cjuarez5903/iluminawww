(function mounted() {
    getTableData();
})();

function guid() {

    var url_string = window.location.href
    var url = new URL(url_string);
    var c = url.searchParams.get("idPostec");
    return c;
}


function guidD() {

    /*
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1;//January is 0, so always add + 1

    var yyyy = new Date().getFullYear().toString().substr(-2)
    if (dd < 10) { dd = '0' + dd }
    if (mm < 10) { mm = '0' + mm }
    today = yyyy+dd + mm ;

    var d = new Date();
    var h = d.getHours();
    var m = d.getMinutes();
    var s = d.getSeconds();
    return resultado = `${today}${h}${m}${s}`;
    */

   function cero(n) {
    return (n < 10) ? '0' + n : n;
}

var today = new Date();
var dd = today.getDate();
var mm = today.getMonth() + 1;

var yyyy = new Date().getFullYear().toString().substr(-2)
if (dd < 10) { dd = '0' + dd }
if (mm < 10) { mm = '0' + mm }
today = yyyy + mm+ dd ;

var d = new Date();
var HH = d.getHours(HH);
var MM = d.getMinutes(MM);
var ss = d.getSeconds(ss);

if (HH > 12) {
   HH -= 12;
} else if (HH === 0) {
   HH = 12;
}

var HHMM = cero(HH) + cero(MM);
return resultado = `${today}${HHMM}${ss}`;

}


function fecha(){
    n =  new Date();
    //Año
    y = n.getFullYear();
    //Mes
    m = n.getMonth() + 1;
    //Día
    d = n.getDate();

    return fecha = d + "-" + m + "-" + y;
}
   

function saveMemberInfo() {
    var keys = ['luminaria_dropdown', 'tipo_dropdown', 'clase_dropdown', 'pote_disp', 'canti_disp', 'prop_disp', 'estado_disp', 'obs_disp', 'activoRadios1', 'medidoRadios1', 'lat', 
    'long', 'cameraTakePicture'];


    var obj = {};

    keys.forEach(function (item, index) {
        var result = document.getElementById(item).value;
        if (result) {
            obj[item] = result;
        }
    })

    var membersd = getmembersd();

    if (!membersd.length) {
        $('.show-table-info').addClass('hide');
    }

    if (Object.keys(obj).length) {
        var membersd = getmembersd();
        obj.id = guid();
        obj.fecha = fecha();
        obj.iddelete = guidD();
        membersd.push(obj);
        var data = JSON.stringify(membersd);
        localStorage.setItem("membersd", data);


        clearFields();
        insertIntoTableView(obj, getTotalRowOfTable());
        $('#addnewModal').modal('hide')

        location.reload(); 

    }
}

function clearFields() {
    $('#input_form')[0].reset();
}

function getmembersd() {
    var memberRecord = localStorage.getItem("membersd");
    var membersd = [];
    if (!memberRecord) {
        return membersd;
    } else {
        membersd = JSON.parse(memberRecord);
        return membersd;
    }
}

function getFormattedmembersd() {
    var membersd = getmembersd();
    return membersd;
}

/**
 * Populating Table with stored data
 */


 /*
function getTableData() {
    $("#member_table").find("tr:not(:first)").remove();

    var searchKeyword = $('#member_search').val();
    var membersd = getFormattedmembersd();

    var filteredmembersd = membersd.filter(function (item, index) {
        return item.id.toLowerCase().includes(searchKeyword.toLowerCase()) ||
            item.contador.toLowerCase().includes(searchKeyword.toLowerCase()) ||
            item.fecha.toLowerCase().includes(searchKeyword.toLowerCase()) ||
            item.zona.toLowerCase().includes(searchKeyword.toLowerCase())
    });

    if (!filteredmembersd.length) {
        $('.show-table-info').removeClass('hide');
    } else {
        $('.show-table-info').addClass('hide');
    }

    filteredmembersd.forEach(function (item, index) {
        insertIntoTableView(item, index + 1);
    })
}
*/

/**
 * Inserting data into the table of the view
 * 
 * @param {object} item 
 * @param {int} tableIndex 
 */
function insertIntoTableView(item, tableIndex) {
    var table = document.getElementById('member_table');
    var row = table.insertRow();
    var idCell = row.insertCell(0);
    var firstNameCell = row.insertCell(1);
    var lastNameCell = row.insertCell(2);
    var emailCell = row.insertCell(3);
    var fechazona = row.insertCell(4);


    var actionCell = row.insertCell(5);
    
    idCell.innerHTML = tableIndex;
    firstNameCell.innerHTML = item.id;
    lastNameCell.innerHTML = item.luminaria_dropdown;
    emailCell.innerHTML = item.tipo_dropdown;
    fechazona.innerHTML = item.clase_dropdown;

    
    var guid = item.iddelete;

    actionCell.innerHTML = '<button class="btn btn-sm btn-default" onclick="showMemberData(' + guid + ')">Ver</button> ' +
        '<button class="btn btn-sm btn-primary" onclick="showEditModal(' + guid + ')">Editar</button> ' +
        '<button class="btn btn-sm btn-danger" onclick="showDeleteModal(' + guid + ')">Sincronizar</button>';
}


/**
 * Get Total Row of Table
 */
function getTotalRowOfTable() {
    var table = document.getElementById('member_table');
    return table.rows.length;
}

/**
 * Show Single Member Data into the modal
 * 
 * @param {string} id 
 */
function showMemberData(id) {
    var allmembersd = getmembersd();
    var member = allmembersd.find(function (item) {
        return item.iddelete == id;
    })

    $('#show_luminaria_dropdown').val(member.luminaria_dropdown);
    $('#show_tipo_dropdown').val(member.tipo_dropdown);
    $('#show_clase_dropdown').val(member.clase_dropdown);
    $('#show_pote_disp').val(member.pote_disp);
    $('#show_canti_disp').val(member.canti_disp);
    $('#show_prop_disp').val(member.prop_disp);
    $('#show_obs_disp').val(member.obs_disp);
    $('#show_activoRadios1').val(member.activoRadios1);
    $('#show_medidoRadios1').val(member.medidoRadios1);
    $('#show_lat').val(member.lat);
    $('#show_long').val(member.long);
    $('#show_cameraTakePicture').val(member.cameraTakePicture);
    


    $('#showModal').modal();

}


/**
 * Show Edit Modal of a single member
 * 
 * @param {string} id 
 */
function showEditModal(id) {
    var allmembersd = getmembersd();
    var member = allmembersd.find(function (item) {
        return item.iddelete == id;
    })

    $('#edit_luminaria_dropdown').val(member.luminaria_dropdown);
    $('#edit_tipo_dropdown').val(member.tipo_dropdown);
    $('#edit_clase_dropdown').val(member.clase_dropdown);
    $('#edit_pote_disp').val(member.pote_disp);
    $('#edit_canti_disp').val(member.canti_disp);
    $('#edit_prop_disp').val(member.prop_disp);
    $('#edit_obs_disp').val(member.obs_disp);
    $('#edit_activoRadios1').val(member.activoRadios1);
    $('#edit_medidoRadios1').val(member.medidoRadios1);
    $('#edit_lat').val(member.lat);
    $('#edit_long').val(member.long);
    $('#edit_cameraTakePicture').val(member.cameraTakePicture);

    $('#editModal').modal();
}


/**
 * Store Updated Member Data into the storage
*/
function updateMemberData() {

    var allmembersd = getmembersd();
    var memberId = $('#member_id').val();

    var member = allmembersd.find(function (item) {
        return item.iddelete == memberId;
    })

   


    member.luminaria_dropdown = $('#edit_luminaria_dropdown').val();
    member.tipo_dropdown = $('#edit_tipo_dropdown').val();
    member.clase_dropdown = $('#edit_clase_dropdown').val();
    member.pote_disp = $('#edit_pote_disp').val();
    member.canti_disp = $('#edit_canti_disp').val();
    member.prop_disp = $('#edit_prop_disp').val();
    member.obs_disp = $('#edit_obs_disp').val();
    member.activoRadios1 = $('#edit_activoRadios1').val();
    member.medidoRadios1 = $('#edit_medidoRadios1').val();
    member.lat = $('#edit_lat').val();
    member.long = $('#edit_long').val();
    member.cameraTakePicture=$('#edit_cameraTakePicture').val();




    var data = JSON.stringify(allmembersd);
    localStorage.setItem('membersd', data);

    $("#member_table").find("tr:not(:first)").remove();
    getTableData();
    $('#editModal').modal('hide')
}


function showDeleteModal(id) {
    $('#deleted-member-id').val(id);
    $('#deleteDialog').modal();
}


function deleteMemberData() {
    var id = $('#deleted-member-id').val();
    var allmembersd = getmembersd();

    var member = allmembersd.find(function (item) {
        return item.iddelete == id;
    })


    var getInv = localStorage.getItem("inventario");


    $.ajax({
        type: 'post',
        url: 'http://190.149.224.94:9800/ords/gauss/read/insdispositivo2',
        dataType: 'json',
        data: JSON.stringify({
            "tdiscod": member.luminaria_dropdown,
            "poscorr":member.id,
            "inv": getInv,
            "dispcorr": member.iddelete,
            "dpotencia":member.pote_disp,
            "dpropiedad":member.prop_disp,
            "destado":member.estado_disp,
            "dmedido":member.medidoRadios1,
            "dactivo":member.activoRadios1,
            "dx":member.lat,
            "dy":member.long,
            "tipocod":member.tipo_dropdown,
            "clasecod":member.clase_dropdown,
            "dobs":member.obs_disp,
            "dcant":member.canti_disp,
            "dfotoclob":member.cameraTakePicture,
            "dispcont":"A-12347"
        }

        ),
        contentType: 'application/json; charset=utf-8',
        success: function (l) { 
            alert("Done");
        }
    });

    var storageUsers = JSON.parse(localStorage.getItem('membersd'));

    var newData = [];

    newData = storageUsers.filter(function (item, index) {
        return item.iddelete != id;
    });

    var data = JSON.stringify(newData);

    localStorage.setItem('membersd', data);
    $("#member_table").find("tr:not(:first)").remove();
    $('#deleteDialog').modal('hide');
    getTableData();

}

/**
 * Sorting table data through type
 */
function sortBy(type)
{
    $("#member_table").find("tr:not(:first)").remove();

    var totalClickOfType = parseInt(localStorage.getItem(type));
    if(!totalClickOfType) {
        totalClickOfType = 1;
        localStorage.setItem(type, totalClickOfType);
    } else {
        if(totalClickOfType == 1) {
            totalClickOfType = 2;
        } else {
            totalClickOfType = 1;
        }
        localStorage.setItem(type, totalClickOfType);
    }

    var searchKeyword = $('#member_search').val();
    var membersd = getFormattedmembersd();

    var sortedmembersd = membersd.sort(function (a, b) {
        return (totalClickOfType == 2) ? a[type] > b[type] : a[type] < b[type];
    });

    sortedmembersd.forEach(function (item, index) {
        insertIntoTableView(item, index + 1);
    })
}