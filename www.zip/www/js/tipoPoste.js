
$(document).ready(function () {

function createNode(element) {
    return document.createElement(element);
}

function append(parent, el) {
    return parent.appendChild(el);
}

const url2 = 'http://190.149.224.94:9800/ords/gauss/read/clase';
fetch(url2)
    .then((resp) => resp.json())
    .then(function (data) {
        let luminaria = data.items;

        return luminaria.map(function (luminaria) {

            if (typeof (Storage) !== "undefined") {

                var clase = data.items;
                localStorage.setItem('clase', JSON.stringify(clase));
                // localStorage.clear();
            }

            if (typeof (Storage) !== "undefined") {

                var lumi = localStorage.getItem('clase');
                var lumis = JSON.parse(localStorage.getItem('clase'));

                //alert(lumis);
            }

            var sel2 = document.getElementById('clase-dropdown');

            // create new option element
            var opt2 = document.createElement('option');




            // create text node to add to option element (opt)

            opt2.appendChild(document.createTextNode(`${luminaria.clase_nom}`));

            // set value property of opt
            opt2.value = `${luminaria.clase_cod}`;

            // add opt to end of select box (sel)
            sel2.appendChild(opt2);
        })
    })
    .catch(function (error) {
        console.log(error);
    });




const ul = document.getElementById('tipopos_dropdown');
const url = 'http://190.149.224.94:9800/ords/gauss/read/tposte';
fetch(url)
    .then((resp) => resp.json())
    .then(function (data) {
        let tipopostes = data.items;
        return tipopostes.map(function (tipoposte) {

            if (typeof (Storage) !== "undefined") {

                var tipo = data.items;
                localStorage.setItem('tipo', JSON.stringify(tipo));
                // localStorage.clear();
            }

            if (typeof (Storage) !== "undefined") {

                var tipo = localStorage.getItem('tipo');
                var tiposs = JSON.parse(localStorage.getItem('tipo'));

                //alert(lumis);
            }


            var sel = document.getElementById('tipopos_dropdown');

            // create new option element
            var opt = document.createElement('option');

            // create text node to add to option element (opt)
            opt.appendChild(document.createTextNode(`${tipoposte.tpos_nom}`));

            // set value property of opt
            opt.value = `${tipoposte.tpos_cod}`;

            // add opt to end of select box (sel)
            sel.appendChild(opt);

        })
    })
    .catch(function (error) {
        console.log(error);
    });
/*
    $('#departamento-dropdown').change(function(){
        var DP = document.getElementById("departamento-dropdown").value;
        alert(DP)
        */

try {
    const url2 = 'http://190.149.224.94:9800/ords/gauss/read/tdispositivo';
    fetch(url2)
        .then((resp) => resp.json())
        .then(function (data) {
            let luminaria = data.items;

            return luminaria.map(function (luminaria) {

                if (typeof (Storage) !== "undefined") {

                    var lumi = data.items;
                    localStorage.setItem('lumi', JSON.stringify(lumi));
                    // localStorage.clear();
                }

                if (typeof (Storage) !== "undefined") {

                    var lumi = localStorage.getItem('lumi');
                    var lumis = JSON.parse(localStorage.getItem('lumi'));

                    //alert(lumis);
                }

                var sel2 = document.getElementById('luminaria-dropdown');

                // create new option element
                var opt2 = document.createElement('option');




                // create text node to add to option element (opt)

                opt2.appendChild(document.createTextNode(`${luminaria.tdis_nom}`));

                // set value property of opt
                opt2.value = `${luminaria.tdis_cod}`;

                // add opt to end of select box (sel)
                sel2.appendChild(opt2);
            })
        })
        .catch(function (error) {
            console.log(error);
        });


} catch (error) {

    var lumis = JSON.parse(localStorage.getItem('lumi'));
    // console.log(lumis[0].lumi_cod)

    var temp = lumis;
    for (var key in temp) {
        alert('<option value=' + lumis[key].lumi_cod + '>' + lumis[key].lumi_nom + '</option>');

        var sel2 = document.getElementById('luminaria-dropdown');

        // create new option element
        var opt2 = document.createElement('option');

        // create text node to add to option element (opt)

        opt2.appendChild(document.createTextNode(`${lumis[key].lumi_nom}`));

        // set value property of opt
        opt2.value = `${lumis[key].lumi_cod}`;

        // add opt to end of select box (sel)
        sel2.appendChild(opt2);
    }

}

const url3= 'http://190.149.224.94:9800/ords/gauss/read/tipo';
fetch(url3)
    .then((resp) => resp.json())
    .then(function (data) {
        let luminaria = data.items;

            return luminaria.map(function (luminaria) {

                if (typeof (Storage) !== "undefined") {

                    var lumi = data.items;
                    localStorage.setItem('Tipo', JSON.stringify(lumi));
                    // localStorage.clear();
                }

                if (typeof (Storage) !== "undefined") {

                    var lumi = localStorage.getItem('Tipo');
                    var lumis = JSON.parse(localStorage.getItem('Tipo'));

                    //alert(lumis);
                }

                var sel2 = document.getElementById('tipo-dropdown');

                // create new option element
                var opt2 = document.createElement('option');




                // create text node to add to option element (opt)

                opt2.appendChild(document.createTextNode(`${luminaria.tipo_nom}`));

                // set value property of opt
                opt2.value = `${luminaria.tipo_cod}`;

                // add opt to end of select box (sel)
                sel2.appendChild(opt2);
            })
    })
    .catch(function (error) {
        console.log(error);
    });


});

