/*
       Licensed to the Apache Software Foundation (ASF) under one
       or more contributor license agreements.  See the NOTICE file
       distributed with this work for additional information
       regarding copyright ownership.  The ASF licenses this file
       to you under the Apache License, Version 2.0 (the
       "License"); you may not use this file except in compliance
       with the License.  You may obtain a copy of the License at

         http://www.apache.org/licenses/LICENSE-2.0

       Unless required by applicable law or agreed to in writing,
       software distributed under the License is distributed on an
       "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
       KIND, either express or implied.  See the License for the
       specific language governing permissions and limitations
       under the License.
*/

var deviceInfo = function() {
    document.getElementById("platform").innerHTML = device.platform;
    document.getElementById("version").innerHTML = device.version;
    document.getElementById("uuid").innerHTML = device.uuid;
    document.getElementById("name").innerHTML = device.name;
    document.getElementById("width").innerHTML = screen.width;
    document.getElementById("height").innerHTML = screen.height;
    document.getElementById("colorDepth").innerHTML = screen.colorDepth;
};



var beep = function() {
    var my_media = new Media("beep.wav",
        // success callback
        function() {
            console.log("playAudio():Audio Success");
        },
        // error callback
        function(err) {
            console.log("playAudio():Audio Error: "+err);
    }).play();
};

var vibrate = function() {
    navigator.vibrate(500);
};

var preventBehavior = function(e) {
    e.preventDefault();
};

function dump_pic(data) {
    var viewport = document.getElementById('viewport');
    //viewport.style.display = "";
    viewport.style.position = "static";
    viewport.style.top = "10px";
    viewport.style.left = "10px";
    viewport.style.height="auto";
    viewport.style.width = "auto";
    document.getElementById("test_img").src = "data:image/jpeg;base64," + data;
}

function fail(msg) {
    alert(msg);
}

function show_pic() {
    navigator.camera.getPicture(dump_pic, fail, {
        quality : 50,
        destinationType: Camera.DestinationType.DATA_URL,
        targetWidth: 100,
        targetHeight: 100
    });
}

function close() {
    var viewport = document.getElementById('viewport');
    viewport.style.position = "relative";
    viewport.style.display = "none";
}

function check_network() {
    //var networkState = navigator.network.connection.type;
    var networkState = navigator.connection.type;

    //var networkState = alert('prueba');
    
    var states = {};
    states[Connection.UNKNOWN]  = 'Desconocida conexion';
    states[Connection.ETHERNET] = 'Datos celulares';
    states[Connection.WIFI]     = 'Conexion WiFi';
    states[Connection.CELL_2G]  = 'Cell 2G conexion';
    states[Connection.CELL_3G]  = 'Cell 3G conexion';
    states[Connection.CELL_4G]  = 'Cell 4G conexion';
    states[Connection.NONE]     = 'No hay conexion a internet, por favor encienda sus datos o una red Wifi.';

    confirm('Tipo de Conexion a internet:\n ' + states[networkState]);
    navigator.vibrate(800);

    if (states[networkState] === 'Conexion WiFi' || states[networkState] === 'Cell 2G conexion' || states[networkState] === 'Cell 3G conexion' || states[networkState] === 'Cell 4G conexion'|| states[networkState] === 'Datos celulares' ) {

        datos = "Conectados"
        signal = "signal.png"

       localStorage.setItem("datos", datos);
       localStorage.setItem("senal", signal);
        
    } else {

            signal = "nosignal.png"

            datos = "Desconectados"
            

            localStorage.setItem("datos", datos);
            localStorage.setItem("senal", signal);

        
    }

                            var iv = localStorage.getItem("datos");
                            var sim = localStorage.getItem("senal");
                            var urlsim = "images/icons/black/" + sim;
                            document.getElementById("datos").value = iv; 
                             document.getElementById("seal").src = urlsim; 
}

function init() {
    // the next line makes it impossible to see Contacts on the HTC Evo since it
    // doesn't have a scroll button
    // document.addEventListener("touchmove", preventBehavior, false);
    document.addEventListener("deviceready", deviceInfo, true);
}
