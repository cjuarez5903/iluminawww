

/*$(document).ready(function(){
	$('.abm-splash-screen-wrap').fadeOut(6000);
    
    setTimeout(function(){location.href="login.html"} , 5000);
});*/