
function createNode(element) {
    return document.createElement(element);
}

function append(parent, el) {
    return parent.appendChild(el);
}
try {

    const url = 'http://190.149.224.94:9800/ords/gauss/read/departamento';
    fetch(url)
        .then((resp) => resp.json())
        .then(function (data) {
            let departamentos = data.items;
            return departamentos.map(function (departamento) {

                if (typeof (Storage) !== "undefined") {

                    var deptos = data.items;
                    localStorage.setItem('deptos', JSON.stringify(deptos));
                    //Build an array containing Customer records.



                } else {



                }








            })
        })





    /*
        $('#departamento-dropdown').change(function(){
            var DP = document.getElementById("departamento-dropdown").value;
            alert(DP)
            */


} catch (error) {
    console.log(error);
}

//Inicia el select Departtamentos
try {
    var departamentolocal = localStorage.getItem("deptos");
    var departamentoslocal = JSON.parse(departamentolocal);
    var ddldepartamentoslocal = document.getElementById("departamento-dropdown");

    for (var i = 0; i <= departamentoslocal.length; i++) {
        var option = document.createElement("OPTION");
        console.log("entre ")
        //Set Customer Name in Text part.
        option.innerHTML = departamentoslocal[i].depto_nom;

        //Set CustomerId in Value part.
        option.value = departamentoslocal[i].depto_cod;

        //Add the Option element to DropDownList.
        ddldepartamentoslocal.options.add(option);

        console.log(i);
    }
    //Termina el select local de Departamentos

} catch (error) {
    console.log(error);
}



try {
    const url2 = 'http://190.149.224.94:9800/ords/gauss/read/municipio';
    fetch(url2)
        .then((resp) => resp.json())
        .then(function (data) {
            let municipio = data.items;

            return municipio.map(function (municipio) {

                if (typeof (Storage) !== "undefined") {

                    var muni = data.items;
                    localStorage.setItem('muni', JSON.stringify(muni));
                    //Build an array containing Customer records.
                    var municipio = localStorage.getItem("muni");
                    var municipios = JSON.parse(municipio);
                    var ddlMunicipios = document.getElementById("municipio-dropdown");

                    /*Add the Options to the DropDownList.
                    for (var i = 0; i <= municipios.length; i++) {
                        var option = document.createElement("OPTION");

                        //Set Customer Name in Text part.
                        option.innerHTML = municipios[i].muni_nom;

                        //Set CustomerId in Value part.
                        option.value = municipios[i].muni_cod;

                        //Add the Option element to DropDownList.
                        ddlMunicipios.options.add(option);

                        console.log(i);
                    }

*/
                    //console.log(munis);
                    // localStorage.clear();
                }

                /*

 var sel2 = document.getElementById('municipio-dropdown');

 // create new option element
 var opt2 = document.createElement('option');




 // create text node to add to option element (opt)

 opt2.appendChild(document.createTextNode(`${municipio.muni_nom}`));

 // set value property of opt
 opt2.value = `${municipio.muni_cod}`;

 // add opt to end of select box (sel)
 sel2.appendChild(opt2);*/
            })
        })
        .catch(function (error) {
            console.log(error);
        });//Inicia el select Municipios

    try {
        var municipiolocal = localStorage.getItem("muni");
        var municipioslocal = JSON.parse(municipiolocal);
        var ddlMunicipioslocal = document.getElementById("municipio-dropdown");

        for (var i = 0; i <= municipioslocal.length; i++) {
            var option = document.createElement("OPTION");

            //Set Customer Name in Text part.
            option.innerHTML = municipioslocal[i].muni_nom;

            //Set CustomerId in Value part.
            option.value = municipioslocal[i].muni_cod;

            //Add the Option element to DropDownList.
            ddlMunicipioslocal.options.add(option);

            console.log(i);
        }

        //Termina el select local de municipios

    } catch (error) {
        console.log(error)
    }




}
finally {

    var showCity = function (selectedState) {
        $('#municipio-dropdown option').hide();
        $('#municipio-dropdown').find('option').filter(function () {
            var city = $(this).text().substring(0,4);
            return city.indexOf(selectedState) != -1;
        }).show();
        //set default value
        var defaultCity = $('#municipio-dropdown option:visible:first').text();
        $('#municipio-dropdown').val(defaultCity);
    };

    //set default state
    var state = $('#departamento-dropdown').val();
    showCity(state);
    $('#departamento-dropdown').change(function () {
        showCity($(this).val());
    });



}



