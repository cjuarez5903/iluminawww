(function mounted() {
    getTableData();
})();

function guid() {
    //return parseInt(Date.now() + Math.random());
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1;//January is 0, so always add + 1

    var yyyy = new Date().getFullYear().toString().substr(-2)
    if (dd < 10) { dd = '0' + dd }
    if (mm < 10) { mm = '0' + mm }
    today = yyyy+dd + mm ;

    var d = new Date();
    var h = d.getHours();
    var m = d.getMinutes();
    var s = d.getSeconds();
    return resultado = `${today}${h}${m}${s}`;
}


function fecha(){
    n =  new Date();
    //Año
    y = n.getFullYear();
    //Mes
    m = n.getMonth() + 1;
    //Día
    d = n.getDate();

    return fecha = d + "-" + m + "-" + y;
}
   

function saveMemberInfo() {
 
    var keys = ['nposte2', 'tipopos_dropdown','contador', 'calle', 'nocasa', 'zona', 'dir1', 'dir2', 'propiedad', 'obtext', 'cameraTakePicture', 'latpos', 'longpos']
    var obj = {};

    keys.forEach(function (item, index) {
        var result = document.getElementById(item).value;
        if (result) {
            obj[item] = result;
        }
    })

    var members = getMembers();

    if (!members.length) {
        $('.show-table-info').addClass('hide');
    }

    if (Object.keys(obj).length) {
        var members = getMembers();
        obj.id = guid();
        obj.fecha = fecha();
        members.push(obj);
        var data = JSON.stringify(members);
        localStorage.setItem("members", data);
        clearFields();
        insertIntoTableView(obj, getTotalRowOfTable());
        $('#addnewModal').modal('hide')
    }
}

function clearFields() {
    $('#input_form')[0].reset();
}

function getMembers() {
    var memberRecord = localStorage.getItem("members");
    var members = [];
    if (!memberRecord) {
        return members;
    } else {
        members = JSON.parse(memberRecord);
        return members;
    }
}

function getFormattedMembers() {
    var members = getMembers();
    return members;
}

/**
 * Populating Table with stored data
 */
function getTableData() {
    $("#member_table").find("tr:not(:first)").remove();

    var searchKeyword = $('#member_search').val();
    var members = getFormattedMembers();

    var filteredMembers = members.filter(function (item, index) {
        return item.id.toLowerCase().includes(searchKeyword.toLowerCase()) ||
            item.contador.toLowerCase().includes(searchKeyword.toLowerCase()) ||
            item.fecha.toLowerCase().includes(searchKeyword.toLowerCase()) ||
            item.zona.toLowerCase().includes(searchKeyword.toLowerCase())
    });

    if (!filteredMembers.length) {
        $('.show-table-info').removeClass('hide');
    } else {
        $('.show-table-info').addClass('hide');
    }

    filteredMembers.forEach(function (item, index) {
        insertIntoTableView(item, index + 1);
    })
}

/**
 * Inserting data into the table of the view
 * 
 * @param {object} item 
 * @param {int} tableIndex 
 */
function insertIntoTableView(item, tableIndex) {
    var table = document.getElementById('member_table');
    var row = table.insertRow();
    var idCell = row.insertCell(0);
    var firstNameCell = row.insertCell(1);
    var lastNameCell = row.insertCell(2);
    var emailCell = row.insertCell(3);
    var fechazona = row.insertCell(4);


    var actionCell = row.insertCell(5);
    
    idCell.innerHTML = tableIndex;
    firstNameCell.innerHTML = item.id;
    lastNameCell.innerHTML = item.contador;
    emailCell.innerHTML = item.fecha;
    fechazona.innerHTML = item.calle +" "+item.nocasa+" "+item.zona+" "+item.dir1;

    
    var guid = item.id;

    actionCell.innerHTML = '<button class="btn btn-sm btn-default" onclick="showMemberData(' + guid + ')">Ver</button> ' +
        '<button class="btn btn-sm btn-primary" onclick="showEditModal(' + guid + ')">Editar</button> ' +
        '<button class="btn btn-sm btn-danger" onclick="showDeleteModal(' + guid + ')">Sincronizar</button>';
}


/**
 * Get Total Row of Table
 */
function getTotalRowOfTable() {
    var table = document.getElementById('member_table');
    return table.rows.length;
}

/**
 * Show Single Member Data into the modal
 * 
 * @param {string} id 
 */
function showMemberData(id) {
    var allMembers = getMembers();
    var member = allMembers.find(function (item) {
        return item.id == id;
    })

    $('#show_poste').val(member.nposte2);
    $('#tipopos_dropdown_show').val(member.tipopos_dropdown);
    $('#show_contador_ref').val(member.contador);
    $('#show_calle').val(member.calle);
    $('#show_nocasa').val(member.nocasa);
    $('#show_Zona').val(member.zona);
    $('#show_dir1').val(member.dir1);
    $('#show_dir2').val(member.dir2);
    $('#show_propiedad').val(member.propiedad);
    $('#show_obtext').val(member.obtext);
    $('#show_latpos').val(member.latpos);
    $('#show_longpos').val(member.longpos);
    $('#member_id').val(id);


    $('#showModal').modal();

}


/**
 * Show Edit Modal of a single member
 * 
 * @param {string} id 
 */
function showEditModal(id) {
    var allMembers = getMembers();
    var member = allMembers.find(function (item) {
        return item.id == id;
    })

    $('#edit_poste').val(member.nposte2);
    $('#tipopos_dropdown_edit').val(member.tipopos_dropdown);
    $('#edit_contador_ref').val(member.contador);
    $('#edit_calle').val(member.calle);
    $('#edit_nocasa').val(member.nocasa);
    $('#edit_Zona').val(member.zona);
    $('#edit_dir1').val(member.dir1);
    $('#edit_dir2').val(member.dir2);
    $('#edit_propiedad').val(member.propiedad);
    $('#edit_obtext').val(member.obtext);
    $('#edit_latpos').val(member.latpos);
    $('#edit_longpos').val(member.longpos);
    $('#member_id').val(id);
    $('#editModal').modal();
}


/**
 * Store Updated Member Data into the storage
*/
function updateMemberData() {

    var allMembers = getMembers();
    var memberId = $('#member_id').val();

    var member = allMembers.find(function (item) {
        return item.id == memberId;
    })

   // member.nposte2= $('#edit_poste').val();
    member.tipopos_dropdown=$('#tipopos_dropdown_edit').val();
    //member.contador=$('#edit_contador_ref').val();
    member.calle=$('#edit_calle').val();
    member.nocasa=$('#edit_nocasa').val();
    member.zona=$('#edit_Zona').val();
    member.dir1=$('#edit_dir1').val();
    member.dir2=$('#edit_dir2').val();
    member.propiedad=$('#edit_propiedad').val();
    member.obtext=$('#edit_obtext').val();
    member.latpos=$('#edit_latpos').val();
    member.longpos=$('#edit_longpos').val();

 

    var data = JSON.stringify(allMembers);
    localStorage.setItem('members', data);

    $("#member_table").find("tr:not(:first)").remove();
    getTableData();
    $('#editModal').modal('hide')
}


function showDeleteModal(id) {
    $('#deleted-member-id').val(id);
    $('#deleteDialog').modal();
}


function deleteMemberData() {
    var id = $('#deleted-member-id').val();
    var allMembers = getMembers();

    var storageUsers = JSON.parse(localStorage.getItem('members'));

    var newData = [];

    newData = storageUsers.filter(function (item, index) {
        return item.id != id;
    });

    var data = JSON.stringify(newData);

    localStorage.setItem('members', data);
    $("#member_table").find("tr:not(:first)").remove();
    $('#deleteDialog').modal('hide');
    getTableData();

}

/**
 * Sorting table data through type
 */
function sortBy(type)
{
    $("#member_table").find("tr:not(:first)").remove();

    var totalClickOfType = parseInt(localStorage.getItem(type));
    if(!totalClickOfType) {
        totalClickOfType = 1;
        localStorage.setItem(type, totalClickOfType);
    } else {
        if(totalClickOfType == 1) {
            totalClickOfType = 2;
        } else {
            totalClickOfType = 1;
        }
        localStorage.setItem(type, totalClickOfType);
    }

    var searchKeyword = $('#member_search').val();
    var members = getFormattedMembers();

    var sortedMembers = members.sort(function (a, b) {
        return (totalClickOfType == 2) ? a[type] > b[type] : a[type] < b[type];
    });

    sortedMembers.forEach(function (item, index) {
        insertIntoTableView(item, index + 1);
    })
}