
function createNode(element) {
    return document.createElement(element);
}

function append(parent, el) {
    return parent.appendChild(el);
}

const url2 = 'http://190.149.224.94:9800/ords/gauss/read/clase';
fetch(url2)
    .then((resp) => resp.json())
    .then(function (data) {
        let luminaria = data.items;

        return luminaria.map(function (luminaria) {

            if (typeof (Storage) !== "undefined") {

                var clase = data.items;
                localStorage.setItem('clase', JSON.stringify(clase));
                // localStorage.clear();
                var clase = localStorage.getItem("clase");

            }



        })
    })
    .catch(function (error) {
        console.log(error);
    });

try {
    var claselocal = localStorage.getItem("clase");
    var claseslocal = JSON.parse(claselocal);
    var ddclaseslocal = document.getElementById("clase_dropdown");

    for (var i = 0; i <= claseslocal.length; i++) {
        var option = document.createElement("OPTION");

        //Set Customer Name in Text part.
        option.innerHTML = claseslocal[i].clase_nom;

        //Set CustomerId in Value part.
        option.value = claseslocal[i].clase_cod;

        //Add the Option element to DropDownList.
        ddclaseslocal.options.add(option);

        console.log(i);
    }


} catch (error) {
    console.log(error)
}

const url = 'http://190.149.224.94:9800/ords/gauss/read/tposte';
fetch(url)
    .then((resp) => resp.json())
    .then(function (data) {
        let tipopostes = data.items;
        return tipopostes.map(function (tipoposte) {

            if (typeof (Storage) !== "undefined") {

                var tipo = data.items;
                localStorage.setItem('tipo', JSON.stringify(tipo));
                // localStorage.clear();
            }

        })
    })
    .catch(function (error) {
        console.log(error);
    });
try {
    var tposlocal = localStorage.getItem("tipo");
    var tpostslocal = JSON.parse(tposlocal);
    var ddtpostslocal = document.getElementById("tipopos_dropdown");

    for (var i = 0; i <= claseslocal.length; i++) {
        var option = document.createElement("OPTION");

        //Set Customer Name in Text part.
        option.innerHTML = tpostslocal[i].tpos_nom;

        //Set CustomerId in Value part.
        option.value = tpostslocal[i].tpos_cod;

        //Add the Option element to DropDownList.
        ddtpostslocal.options.add(option);

        console.log(i);
    }

} catch (error) {
    console.log(error)
}
/*
    $('#departamento-dropdown').change(function(){
        var DP = document.getElementById("departamento-dropdown").value;
        alert(DP)
        */

try {
    const url2 = 'http://190.149.224.94:9800/ords/gauss/read/tdispositivo';
    fetch(url2)
        .then((resp) => resp.json())
        .then(function (data) {
            let luminaria = data.items;

            return luminaria.map(function (luminaria) {

                if (typeof (Storage) !== "undefined") {

                    var lumi = data.items;
                    localStorage.setItem('lumi', JSON.stringify(lumi));
                    // localStorage.clear();
                }

            })
        })
        .catch(function (error) {
            console.log(error);
        });
    try {
        var lumilocal = localStorage.getItem("lumi");
        var lumislocal = JSON.parse(lumilocal);
        var ddlumislocal = document.getElementById("luminaria_dropdown");
    
        for (var i = 0; i <= claseslocal.length; i++) {
            var option = document.createElement("OPTION");
    
            //Set Customer Name in Text part.
            option.innerHTML = lumislocal[i].tdis_nom;
    
            //Set CustomerId in Value part.
            option.value = lumislocal[i].tdis_cod;
    
            //Add the Option element to DropDownList.
            ddlumislocal.options.add(option);
    
            console.log(i);
        }

    } catch (error) {
        console.log(error)
    }

} catch (error) {

    var lumis = JSON.parse(localStorage.getItem('lumi'));
    // console.log(lumis[0].lumi_cod)
}

const url3 = 'http://190.149.224.94:9800/ords/gauss/read/tipo';
fetch(url3)
    .then((resp) => resp.json())
    .then(function (data) {
        let luminaria = data.items;

        return luminaria.map(function (luminaria) {

            if (typeof (Storage) !== "undefined") {

                var lumi = data.items;
                localStorage.setItem('Tipo', JSON.stringify(lumi));
                // localStorage.clear();
            }
        })
    })
    .catch(function (error) {
        console.log(error);
    });

    try {
        var tipolocal = localStorage.getItem("Tipo");
        var tiposslocal = JSON.parse(tipolocal);
        var ddtiposlocal = document.getElementById("tipo_dropdown");
    
        for (var i = 0; i <= tiposslocal.length; i++) {
            var option = document.createElement("OPTION");
    
            //Set Customer Name in Text part.
            option.innerHTML = tiposslocal[i].tipo_nom;
    
            //Set CustomerId in Value part.
            option.value = tiposslocal[i].tipo_cod;
    
            //Add the Option element to DropDownList.
            ddtiposlocal.options.add(option);
    
            console.log(i);
        }
        
    } catch (error) {
        console.log(error)
    }



