
function selmuni() {
    var mdrop,Municipiolocal;
         mdrop = document.getElementById("municipio-dropdown");
         Municipiolocal = mdrop.options[mdrop.selectedIndex].text;
        Municipiolocal  =  localStorage.setItem("Municipio", Municipiolocal);
        
}


function seldep() {  
    var ddrop = document.getElementById("departamento-dropdown");
    var DepartamentoLocal = ddrop.options[ddrop.selectedIndex].text;
    DepartamentoLocal =  localStorage.setItem("Departamento", DepartamentoLocal);
}


$(document).ready(function () {

  

    var datos,signal;


   



    $.ajax({
       
        url: "http://www.google.com",
        context: document.body,
        error: function (jqXHR, exception) {
           
            signal = "nosignal.png"

            datos = "Desconectados"
            

            localStorage.setItem("datos", datos);
            localStorage.setItem("senal", signal);

           


        },
        success: function () {

            datos = "Conectados"
             signal = "signal.png"

            localStorage.setItem("datos", datos);
            localStorage.setItem("senal", signal);


        }
    })




$("#continuarpara").click(function () {

    window.location.href = "parametroslocal.html";




});



$("#continuarpara2").click(function () {

    window.location.href = "parametroslocal.html";
});




});

$("#inventariopage").click(function () {

    

    window.location.href = "poste.html";

  



});


$("#cameraTakePicture").click(function (data) {
 

    var viewport = document.getElementById('viewport');
    viewport.style.display = "";
    viewport.style.position = "static";
    viewport.style.top = "10px";
    viewport.style.left = "10px";
    document.getElementById("test_img").src = "data:image/jpeg;base64," + data;

  



});



