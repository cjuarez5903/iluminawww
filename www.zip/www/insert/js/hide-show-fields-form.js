
		
/*

$("#luminaria-dropdown").change(function() {
			if ($(this).val() == "DIR") {     
				$('#selector_tipo').hide();
				$('#selector_clase').hide();
			} 
			else if ($(this).val() == "CAM") {
				$('#selector_tipo').show();
				$('#selector_clase').hide();
			}else if ($(this).val() == "TRANS") {
				$('#selector_tipo').hide();
				$('#selector_clase').hide();
			}else if ($(this).val() == "TRANSU") {
				$('#selector_tipo').hide();
				$('#selector_clase').hide();
			}else if ($(this).val() == "IPASA") {
				$('#selector_tipo').hide();
				$('#selector_clase').hide();
			}else if ($(this).val() == "VALLA") {
				$('#selector_tipo').hide();
				$('#selector_clase').hide();
			}else if ($(this).val() == "PINF") {
				$('#selector_tipo').hide();
				$('#selector_clase').hide();
			}else if ($(this).val() == "MUPIN") {
				$('#selector_tipo').show();
				$('#selector_clase').hide();
			}else if ($(this).val() == "MUPIC") {
				$('#selector_tipo').show();
				$('#selector_clase').hide();
			}                                                                                                  
			
			else {
				$('#selector_tipo').show();
				$('#selector_clase').show();
							
			}
		});
		$("#luminaria-dropdown").trigger("change");
		
*/
			