$('#spanish').click(function () {

    if ($('input[id="spanish"]').is(':checked')) {
        $('#habilitar').attr('disabled', false);

    }
});

$('#english').click(function () {
    if ($('input[id="english"]').is(':checked')) {
        $('#habilitar').attr('disabled', true);

    }

});