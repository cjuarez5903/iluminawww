$(document).ready(function () {

   
    

    $("#loginButton").click(function () {



        navigator.vibrate(500);
        var username = $.trim($("#user").val());
        var password = $.trim($("#password").val());
        var usernametxt = localStorage.getItem("username");

        var userlocal = localStorage.getItem("user");
        var passlocal = localStorage.getItem("pass");

        var usrJson, passJson, urljson;
        var urljson = "http://190.149.224.94:9800/ords/gauss/read/usuario/";
        
        //LOG IN LOCAL
        if (username === userlocal && password === passlocal) {

            alert("Bienvenido  " + usernametxt);
            navigator.vibrate(1000);
            
            window.location.href = "parametroslocal.html";

            // window.location.href = "dispositivo.html";

        }
        //AUTENTICACION JSON
        $("#status").text("Authenticating...");
        $.getJSON(urljson + username, function (data) {

            usrJson = data.usr_usr;
            passJson = data.usr_pwd;
            usernametxt = data.usr_nom;


            if (username === usrJson && password === passJson) {
                $("#status").text("Login Success..!");
                localStorage.setItem("user", username);
                localStorage.setItem("pass", password);
                localStorage.setItem("username", usernametxt)


                datos = "Conectados"
                signal = "signal.png"

                localStorage.setItem("datos", datos);
                localStorage.setItem("senal", signal);

                window.location.href = "parametroslocal.html";


                var text = `Usuario Oracle: ${data.usr_usr}<br>
                        Nombre Oracle: ${data.usr_nom}<br>
                        password Oracle: ${data.usr_pwd}`


                $(".mypanel").html(text);

                alert("Bienvenido  " + usernametxt);


                //localStorage.name = "GeeksforGeeks"; 

                //document.getElementById("nombre").innerHTML = localStorage.getItem("username");


            } else {
                $("#status").text("Login Failed..!");
                window.location.href = "FAIL.html";



            }



        });



    });

    //Obteniendo Inventario Activo 
    var urljsoninve = "http://190.149.224.94:9800/ords/gauss/read/inventario";
    var inventario;
    $.getJSON(urljsoninve, function (data) {

        inventario = data.inv_cod;
        localStorage.setItem("inventario", inventario)
    });


});
